exports.calculateEnerQi = () => {
  return Math.floor(Math.random() * 100);
};

const express = require("express");
const app = express();

app.get("/enerqi", (req, res) => {
  res.json({ score: 88, chakra: "balanced" });
});

app.listen(3001, () => console.log("API running"));

#!/bin/bash

echo "Creating 5DEnerQi Production System..."

# Structure
mkdir -p apps/web/pages
mkdir -p apps/web/components
mkdir -p apps/mobile
mkdir -p backend/api
mkdir -p backend/enerqi-engine
mkdir -p database

# Web App
cat > apps/web/pages/index.tsx << 'EOL'
export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: "sans-serif" }}>
      <h1>5DEnerQi Platform</h1>
      <p>EnerQi Dashboard Active</p>
    </div>
  );
}
EOL

# ChakraBar
cat > apps/web/components/ChakraBar.tsx << 'EOL'
export default function ChakraBar({ chakra, level }) {
  return (
    <div style={{ margin: 10 }}>
      <strong>{chakra}</strong>
      <div style={{ background: "#eee", height: 10 }}>
        <div style={{ width: level + "%", background: "#7B5FFF", height: 10 }} />
      </div>
    </div>
  );
}
EOL

# Mobile
cat > apps/mobile/App.js << 'EOL'
import { Text, View } from "react-native";
export default function App() {
  return <View><Text>5DEnerQi Mobile Ready</Text></View>;
}
EOL

# Backend
cat > backend/api/server.js << 'EOL'
const express = require("express");
const app = express();

app.get("/enerqi", (req, res) => {
  res.json({ score: 88, chakra: "balanced" });
});

app.listen(3001, () => console.log("API running"));
EOL

# EnerQi Engine
cat > backend/enerqi-engine/enerqiCalculator.js << 'EOL'
exports.calculateEnerQi = () => {
  return Math.floor(Math.random() * 100);
};
EOL

# Database
cat > database/init.sql << 'EOL'
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name TEXT,
  enerqi_score INT
);
EOL

# Package files
cat > package.json << 'EOL'
{
  "name": "5denerqi",
  "private": true,
  "scripts": {
    "web": "cd apps/web && npm run dev",
    "api": "node backend/api/server.js"
  }
}
EOL

echo "Done. Zipping project..."

zip -r 5DEnerQi-Platform.zip .

echo "✅ 5DEnerQi Production ZIP Created"

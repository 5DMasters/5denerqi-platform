export default function ChakraBar({ chakra, level }) {
  return (
    <div style={{ margin: 10 }}>
      <strong>{chakra}</strong>
      <div style={{ background: "#eee", height: 10 }}>
        <div style={{ width: level + "%", background: "#7B5FFF", height: 10 }} />
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: "sans-serif" }}>
      <h1>5DEnerQi Platform</h1>
      <p>EnerQi Dashboard Active</p>
    </div>
  );
}

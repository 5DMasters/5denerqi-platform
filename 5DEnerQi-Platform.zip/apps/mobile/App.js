import { Text, View } from "react-native";
export default function App() {
  return <View><Text>5DEnerQi Mobile Ready</Text></View>;
}

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name TEXT,
  enerqi_score INT
);
